from app import db

class VRScene(db.Model):
    """VR场景模型"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)  # 分类：古代建筑、自然景观、文化遗产、民族风情
    image_url = db.Column(db.String(200), nullable=False)  # 预览图片URL
    vr_url = db.Column(db.String(200), nullable=False)  # VR体验链接
    location = db.Column(db.String(100), nullable=True)  # 地理位置
    ethnicity = db.Column(db.String(50), nullable=True)  # 相关民族
    created_at = db.Column(db.DateTime, default=db.func.now())
    updated_at = db.Column(db.DateTime, default=db.func.now(), onupdate=db.func.now())
    
    def __repr__(self):
        return '<VRScene {}>'.format(self.name)
