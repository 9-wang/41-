from flask import Blueprint, render_template, request
from app import db
from app.vr.models import VRScene

# 初始化VR场景数据
def init_vr_scenes():
    # 检查是否已有数据
    if VRScene.query.count() == 0:
        # 预定义VR场景数据
        scenes = [
            {
                'name': '敦煌莫高窟',
                'description': '世界文化遗产，中国古代艺术宝库',
                'category': '文化遗产',
                'image_url': '/static/images/vr/3EE8122D89AE459B7D7149AAB9E0B054B829787D_size1153_w1080_h540.png',
                'vr_url': 'https://285.e-dunhuang.com/#/',
                'location': '甘肃省敦煌市',
                'ethnicity': '多民族'
            },
            {
                'name': '布达拉宫',
                'description': '世界上海拔最高、规模最大的宫堡式建筑群',
                'category': '古代建筑',
                'image_url': '/static/images/import_1734851767391220170011_a700xH.jpg',
                'vr_url': 'https://www.720yun.com/vr/b85jOz4uzv7',
                'location': '西藏自治区拉萨市',
                'ethnicity': '藏族'
            },
            {
                'name': '万里长城',
                'description': '世界七大奇迹之一，中国古代伟大防御工程',
                'category': '文化遗产',
                'image_url': '/static/images/vr/true.png',
                'vr_url': 'https://www.realsee.com/discovery/vr/xJmmEWdJ',
                'location': '北京市延庆区',
                'ethnicity': '汉族'
            },
            {
                'name': '故宫',
                'description': '世界上现存规模最大、保存最为完整的木质结构古建筑之一',
                'category': '古代建筑',
                'image_url': '/static/images/vr/1694748245-iScreen-Shoter-Google-Chrome-230915112326.jpg',
                'vr_url': 'https://pano.dpm.org.cn/#/',
                'location': '北京市东城区',
                'ethnicity': '汉族'
            },
            {
                'name': '兵马俑',
                'description': '世界第八大奇迹，秦始皇陵的陪葬坑',
                'category': '文化遗产',
                'image_url': '/static/images/vr/16161147246041.png',
                'vr_url': 'https://www.720yun.com/vr/98b2dqrfq1v',
                'location': '陕西省西安市',
                'ethnicity': '汉族'
            },
            {
                'name': '鼓浪屿',
                'description': '中国最美五大城区之一，海上花园城市',
                'category': '自然景观',
                'image_url': '/static/images/vr/R-C.jpg',
                'vr_url': 'https://www.720yun.com/t/3a023xaucus?scene_id=1244953',
                'location': '福建省厦门市',
                'ethnicity': '汉族'
            },
            {
                'name': '颐和园',
                'description': '中国现存最大的皇家园林',
                'category': '古代建筑',
                'image_url': '/static/images/vr/3EE8122D89AE459B7D7149AAB9E0B054B829787D_size1153_w1080_h540.png',
                'vr_url': 'https://www.720yun.com/t/21vksyiq577?scene_id=46131685',
                'location': '北京市海淀区',
                'ethnicity': '汉族'
            },
            {
                'name': '天坛',
                'description': '明清两代皇帝祭天、祈谷和祈雨的场所',
                'category': '古代建筑',
                'image_url': '/static/images/vr/3EE8122D89AE459B7D7149AAB9E0B054B829787D_size1153_w1080_h540.png',
                'vr_url': 'https://www.720yun.com/t/83vkcli708q?scene_id=59434172',
                'location': '北京市东城区',
                'ethnicity': '汉族'
            }
        ]
        
        for scene_data in scenes:
            scene = VRScene(**scene_data)
            db.session.add(scene)
        db.session.commit()

# 初始化蓝图
bp = Blueprint('vr', __name__)

@bp.route('/vr/')
def index():
    # 初始化VR场景数据
    init_vr_scenes()
    
    # 获取搜索参数
    search_query = request.args.get('search', '')
    category = request.args.get('category', '')
    ethnicity = request.args.get('ethnicity', '')
    
    # 构建查询
    query = VRScene.query
    
    # 搜索功能
    if search_query:
        query = query.filter(VRScene.name.like(f'%{search_query}%') | VRScene.description.like(f'%{search_query}%'))
    
    # 分类筛选
    if category:
        query = query.filter_by(category=category)
    
    # 民族筛选
    if ethnicity:
        query = query.filter_by(ethnicity=ethnicity)
    
    # 获取所有场景
    scenes = query.all()
    
    # 获取所有分类和民族用于筛选
    categories = db.session.query(VRScene.category).distinct().all()
    categories = [c[0] for c in categories]
    
    ethnicities = db.session.query(VRScene.ethnicity).distinct().all()
    ethnicities = [e[0] for e in ethnicities if e[0]]
    
    return render_template('vr/vr.html', scenes=scenes, categories=categories, ethnicities=ethnicities,
                           search_query=search_query, selected_category=category, selected_ethnicity=ethnicity)

@bp.route('/vr/scene/<int:id>')
def scene(id):
    scene = VRScene.query.get_or_404(id)
    return render_template('vr/scene.html', scene=scene)