from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash
from flask_wtf import FlaskForm
from app import db
from app.user.models import User

bp = Blueprint('user', __name__)

@bp.route('/user/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        identifier = request.form['identifier']  # 可以是用户名、邮箱或手机号
        password = request.form['password']
        
        # 尝试通过用户名、邮箱或手机号查找用户
        user = User.query.filter(
            (User.username == identifier) | 
            (User.email == identifier) |
            (User.phone == identifier)
        ).first()
        
        if user and user.check_password(password):
            login_user(user)
            flash('登录成功！', 'success')
            return redirect(url_for('home.index'))
        else:
            flash('账号或密码错误', 'danger')
    return render_template('user/login.html')

@bp.route('/user/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        # 检查用户名和邮箱是否已存在
        existing_user = User.query.filter_by(username=username).first()
        existing_email = User.query.filter_by(email=email).first()
        
        if existing_user:
            flash('用户名已存在', 'danger')
        elif existing_email:
            flash('邮箱已存在', 'danger')
        elif password != confirm_password:
            flash('密码不一致', 'danger')
        else:
            # 创建新用户
            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            flash('注册成功！请登录', 'success')
            return redirect(url_for('user.login'))
    return render_template('user/register.html')

@bp.route('/user/logout')
def logout():
    logout_user()
    flash('您已成功登出', 'info')
    return redirect(url_for('home.index'))

@bp.route('/user/profile')
@login_required
def profile():
    """用户个人中心"""
    from app.culture.models import EthnicImpression
    # 创建一个空表单用于CSRF保护
    form = FlaskForm()
    # 获取用户收藏的海报
    favorites = current_user.favorited_ethnic_impressions
    return render_template('user/profile.html', user=current_user, favorites=favorites, form=form)

@bp.route('/user/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    """编辑用户个人资料"""
    form = FlaskForm()
    if request.method == 'POST':
        current_user.username = request.form['username']
        current_user.email = request.form['email']
        # 可以在这里添加更多字段的处理，如头像等
        db.session.commit()
        flash('个人资料已更新', 'success')
        return redirect(url_for('user.profile'))
    return render_template('user/edit_profile.html', user=current_user, form=form)