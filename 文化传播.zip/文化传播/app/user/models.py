from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), unique=True, nullable=True)  # 添加手机号字段
    password_hash = db.Column(db.String(128))
    avatar = db.Column(db.String(120), nullable=True)
    created_at = db.Column(db.DateTime, default=db.func.now())
    bio = db.Column(db.Text)  # 个人简介
    ethnicity = db.Column(db.String(50))  # 民族
    school = db.Column(db.String(100))  # 学校
    
    # 登录方式字段，记录用户使用的登录方式
    login_type = db.Column(db.String(20), default='password')  # password, email, phone, wechat, qq, weibo
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256')
    
    def check_password(self, password):
        try:
            return check_password_hash(self.password_hash, password)
        except ValueError as e:
            # 如果遇到不支持的哈希类型，尝试使用pbkdf2:sha256重新哈希密码
            from werkzeug.security import generate_password_hash as gen_hash
            # 检查是否是scrypt不支持的错误
            if 'scrypt' in str(e):
                # 对于旧的scrypt哈希，我们无法直接验证，返回False
                return False
            # 其他ValueError，重新抛出
            raise
    
    def __repr__(self):
        return '<User {}>'.format(self.username)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))